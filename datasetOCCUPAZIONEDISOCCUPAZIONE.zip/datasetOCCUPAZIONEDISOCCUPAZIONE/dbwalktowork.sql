DROP DATABASE IF EXISTS walktowork;
CREATE DATABASE walktowork;
USE walktowork;


DROP TABLE IF EXISTS fontegazzetta;
CREATE TABLE IF NOT EXISTS fontegazzetta (
 id INT NOT NULL AUTO_INCREMENT, 
tipologiaEnte LONGTEXT not NULL,
nomeEnte LONGTEXT not NULL,
tipologia LONGTEXT not NULL,
pubblicazione LONGTEXT not NULL,
scadenza LONGTEXT not NULL,
descrizione LONGTEXT not NULL,
link LONGTEXT not NULL,
  primary key (id)
);

DROP TABLE IF EXISTS datasetdisoccupazione;
CREATE TABLE IF NOT EXISTS datasetdisoccupazione (
 id INT NOT NULL AUTO_INCREMENT, 
anno LONGTEXT not NULL,
regione LONGTEXT not NULL,
percentualedisoccupazione LONGTEXT not NULL,
 primary key (id)
);

DROP TABLE IF EXISTS datasetoccupazione;
CREATE TABLE IF NOT EXISTS datasetoccupazione (
 id INT NOT NULL AUTO_INCREMENT, 
anno LONGTEXT not NULL,
regione LONGTEXT not NULL,
percentualeoccupazione LONGTEXT not NULL,
 primary key (id)
);

